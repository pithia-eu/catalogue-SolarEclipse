2024-09-25

This is a dataset from INL digisonde in SAO.XML 5.0 format containing the 
standard URSI characteristics and electron density profiles derived from 
ionograms during a 2017-08-21 Solar Eclipse event. All data are in the
VERIFIED-CLEAN quality category (manual scaling).

The description of the SAO.XML 5.0 file format and software tools for its I/O
can be found on-line at the URL: https://ulcar.uml.edu/SAOXML

These files can be conveniently read by using the SAO Explorer, which can be 
freely downloaded from the webpage https://ulcar.uml.edu/SAO-X/.
